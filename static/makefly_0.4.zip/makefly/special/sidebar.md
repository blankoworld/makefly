## ${LINKS_TITLE}

  * [${PROJECTNAME} Blog](${PROJECTURL}blog/ "The ${PROJECTNAME} Blog!")
  * [DuckDuckGo Search Engine](http://ddg.gg "DDG Search Engine")
