### Quelque chose

Avec : 

  * une liste
  * des infos
  * du code ?

Non.

### Autre chose

Ou pas.

    bash monscript.sh

Qu'en dis-tu ?
