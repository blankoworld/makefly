Makefly is a *static weblog engine* working thanks to a BSD **makefile**.

It's composed of:

  * home page
  * post's list
  * tag's list

and includes somes functionalities like:

  * RSS feed
  * tags
  * permalink
  * possibility to set posting date (using a _timestamp_)
  * customization using options like max post on homepage
  * translation: English, French

In fact, it's a lightweight weblog engine that generate some HTML files.

