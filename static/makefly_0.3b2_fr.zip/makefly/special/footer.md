${LOGO_AVAILABLE} [Logo sources](${BLOG_URL}/makefly.svg)
