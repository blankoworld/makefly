${LOGO_AVAILABLE} [Logo sources](${BASE_URL}/makefly.svg)
